//
//  SplashView_SwiftUIApp.swift
//  SplashView_SwiftUI
//
//  Created by Anthony Codes on 05/10/2020.
//

import SwiftUI

@main
struct SplashView_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
